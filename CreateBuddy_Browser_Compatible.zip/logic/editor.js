function initEditor() {
  const canvas = document.getElementById('editorCanvas');
  const ctx = canvas.getContext('2d');
  const TILE_SIZE = 32;
  const ROWS = 10;
  const COLS = 10;
  let tiles = Array.from({ length: ROWS }, () => Array(COLS).fill(0));

  canvas.addEventListener('click', e => {
    const rect = canvas.getBoundingClientRect();
    const x = Math.floor((e.clientX - rect.left) / TILE_SIZE);
    const y = Math.floor((e.clientY - rect.top) / TILE_SIZE);
    tiles[y][x] = (tiles[y][x] + 1) % 2;
    draw();
  });

  function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    for (let y = 0; y < ROWS; y++) {
      for (let x = 0; x < COLS; x++) {
        ctx.fillStyle = tiles[y][x] ? '#000' : '#ccc';
        ctx.fillRect(x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE);
      }
    }
  }

  draw();

  window.saveLevel = () => {
    document.getElementById('levelData').textContent = JSON.stringify(tiles);
  };

  window.downloadLevel = () => {
    const blob = new Blob([JSON.stringify(tiles)], { type: 'application/json' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'level.json';
    link.click();
  };
}