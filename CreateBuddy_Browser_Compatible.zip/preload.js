const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('electronAPI', {
  fetchAsset: (prompt) => ipcRenderer.invoke('fetch-asset', prompt),
});