function startPreview() {
  const config = {
    type: Phaser.AUTO,
    width: 320,
    height: 320,
    backgroundColor: '#222',
    scene: {
      create() {
        this.add.text(100, 150, 'Game Preview', { fill: '#fff' });
      },
    },
    parent: 'phaserGame'
  };
  new Phaser.Game(config);
}