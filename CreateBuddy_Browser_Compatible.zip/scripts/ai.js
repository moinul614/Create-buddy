async function generateAsset() {
  const prompt = document.getElementById('prompt').value;
  const output = document.getElementById('output');
  output.innerText = 'Generating...';
  try {
    const response = { message: 'This is a mock asset response for browser use.' };
    output.innerText = JSON.stringify(response, null, 2);
  } catch (err) {
    output.innerText = 'Failed to generate asset.';
  }
}