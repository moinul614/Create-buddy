function loadSection(section) {
  const content = document.getElementById('content');
  if (section === 'assets') {
    content.innerHTML = `
      <h2>Asset Generator</h2>
      <input type="text" id="prompt" placeholder="Enter prompt">
      <button onclick="generateAsset()">Generate</button>
      <pre id="output"></pre>`;
  } else if (section === 'levels') {
    content.innerHTML = `
      <h2>Level Editor</h2>
      <canvas id="editorCanvas" width="320" height="320" style="border:1px solid #000"></canvas>
      <button onclick="saveLevel()">Save</button>
      <button onclick="downloadLevel()">Download</button>
      <pre id="levelData"></pre>`;
    initEditor();
  } else if (section === 'code') {
    content.innerHTML = `<h2>Code Editor</h2><div id="editor" style="height:600px;"></div>`;
    require.config({ paths: { vs: 'https://cdn.jsdelivr.net/npm/monaco-editor@0.45.0/min/vs' }});
    require(['vs/editor/editor.main'], function () {
      monaco.editor.create(document.getElementById('editor'), {
        value: '// Write your game logic here...',
        language: 'javascript',
        theme: 'vs-dark'
      });
    });
  } else if (section === 'preview') {
    content.innerHTML = `<h2>Game Preview</h2><div id="phaserGame"></div>`;
    startPreview();
  }
}